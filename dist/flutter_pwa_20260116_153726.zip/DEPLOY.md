# Flutter Web PWA 部署指南

## 快速部署

### 方式 1：Vercel（推荐）
```bash
npm i -g vercel
vercel --prod
```

### 方式 2：Netlify
1. 拖拽此文件夹到 [netlify.com/drop](https://app.netlify.com/drop)
2. 自动部署完成

### 方式 3：Firebase Hosting
```bash
npm i -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

### 方式 4：Nginx
1. 将文件复制到 `/var/www/html`
2. 参考 `nginx.conf.example` 配置
3. 重启 Nginx: `sudo systemctl restart nginx`

### 方式 5：Apache
1. 将文件复制到网站根目录
2. `.htaccess` 已自动生成
3. 确保启用 `mod_rewrite` 和 `mod_deflate`

## 重要提示

⚠️ **必须使用 HTTPS，否则无法安装 PWA**

检查清单：
- [ ] 已配置 HTTPS 证书
- [ ] manifest.json 正确配置
- [ ] 图标文件完整（192x192, 512x512）
- [ ] Service Worker 正常加载

## 测试 PWA

### Android
1. 使用 Chrome 打开网址
2. 点击地址栏「安装」图标
3. 桌面出现 App 图标

### iOS
1. 使用 Safari 打开网址
2. 点击「分享」→「添加到主屏幕」
3. 完成安装

## 性能优化建议

1. 启用 CDN 加速
2. 配置 Gzip/Brotli 压缩
3. 设置静态资源缓存
4. 使用 HTTP/2

## 常见问题

### Service Worker 未更新
```bash
# 清除浏览器缓存
# Chrome: DevTools → Application → Clear Storage
```

### 图标未显示
- 检查图标路径是否正确
- 确保图标尺寸准确
- 验证 MIME 类型

---

**构建时间**: $(date)
**Flutter 版本**: $(flutter --version | head -n 1)
